'''
Write a Python program that removes all duplicate elements from an array 
and returns a new array.
Sample Output:
Original array: 1 3 5 1 3 7 9
After removing duplicate elements from the said array: 1 3 5 7 9
Original array: 2 4 2 6 4 8
After removing duplicate elements from the said array:2 4 6 8

'''

array=[]

n=int(input("enter the array length:"))

for i in range(n):
    array.append(int(input("enter the elements:")))
    
print("Original array",array)


array2 = []
for i in array:
    if i not in array2:
        array2.append(i)



'''
-----------------------------------------
another method with builtin function
array2=list(set(array))
-----------------------------------------
'''


print("After removing duplicate elements from the array",array2)













